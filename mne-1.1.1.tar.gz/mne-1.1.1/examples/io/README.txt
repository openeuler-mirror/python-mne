
Input/Output
------------

Recipes for reading and writing files. See also our :ref:`tutorials on reading
data from various recording systems <tut-data-formats>` and our :ref:`tutorial
on manipulating MNE-Python data structures <tut-creating-data-structures>`.
