
Forward modeling
----------------

From BEM segmentation, coregistration, setting up source spaces
to actual computation of forward solution.
