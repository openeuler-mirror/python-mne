"""Multimodal dataset."""

from .phantom_4dbti import data_path, has_phantom_4dbti_data, get_version
