"""Somatosensory dataset."""

from .somato import data_path, has_somato_data, get_version
