"""fNIRS motor dataset."""

from .fnirs_motor import data_path, has_fnirs_motor_data, get_version
