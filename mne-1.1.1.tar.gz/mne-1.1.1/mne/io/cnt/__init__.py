"""CNT data reader."""

from .cnt import read_raw_cnt
