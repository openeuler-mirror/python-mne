"""BTi module for conversion to FIF."""

# Author: Denis A. Engemann <denis.engemann@gmail.com>

from .bti import read_raw_bti
