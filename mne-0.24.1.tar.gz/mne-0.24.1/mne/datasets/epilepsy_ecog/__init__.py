"""Clinical epilepsy datasets."""

from ._data import data_path, has_epilepsy_ecog_data, get_version
