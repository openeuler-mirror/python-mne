"""SSVEP dataset."""

from .ssvep import data_path, has_ssvep_data, get_version
