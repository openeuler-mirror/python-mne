"""BrainVision module for conversion to FIF."""

# Author: Teon Brooks <teon.brooks@gmail.com>
#         Stefan Appelhoff <stefan.appelhoff@mailbox.org>
#
# License: BSD-3-Clause

from .brainvision import read_raw_brainvision
