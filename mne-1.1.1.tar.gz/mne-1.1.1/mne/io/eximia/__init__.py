"""Eximia module for conversion to FIF."""

# Author: Eric Larson <larson.eric.d@gmail.com>
#
# License: BSD-3-Clause

from .eximia import read_raw_eximia
