"""Clinical epilepsy datasets."""

from ._data import data_path, get_version
