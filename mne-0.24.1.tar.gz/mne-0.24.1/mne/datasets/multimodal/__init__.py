"""Multimodal dataset."""

from .multimodal import data_path, has_multimodal_data, get_version
