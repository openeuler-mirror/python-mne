# Authors: Eric Larson <larson.eric.d@gmail.com>
# License: BSD Style.

from .commands.utils import main

if __name__ == '__main__':
    main()
