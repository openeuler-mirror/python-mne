"""MNE misc dataset."""

from ._misc import data_path, _pytest_mark
