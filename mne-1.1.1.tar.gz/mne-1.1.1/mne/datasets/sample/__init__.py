"""MNE sample dataset."""

from .sample import data_path, get_version
