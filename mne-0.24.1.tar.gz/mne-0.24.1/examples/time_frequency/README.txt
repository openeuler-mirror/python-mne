
Time-Frequency Examples
-----------------------

Some examples of how to explore time-frequency content of M/EEG data with MNE.
