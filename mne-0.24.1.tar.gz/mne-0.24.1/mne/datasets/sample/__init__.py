"""MNE sample dataset."""

from .sample import data_path, has_sample_data, get_version
