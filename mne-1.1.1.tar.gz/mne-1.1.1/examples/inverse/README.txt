
Inverse problem and source analysis
-----------------------------------

Estimate source activations, extract activations in
labels, morph data between subjects etc.

