"""SSVEP dataset."""

from .ssvep import data_path, get_version
