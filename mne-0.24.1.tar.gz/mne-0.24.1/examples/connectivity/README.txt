
Connectivity Analysis Examples
------------------------------

Examples demonstrating connectivity analysis in sensor and source space.

.. note::
    Connectivity functionality has moved into the
    :mod:`mne-connectivity:mne_connectivity` package. Examples can be found at
    :ref:`mne-connectivity:sphx_glr_auto_examples`.
