"""LIMO Dataset."""

from .limo import data_path, load_data
