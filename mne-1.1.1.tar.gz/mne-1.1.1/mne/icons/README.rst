.. -*- mode: rst -*-


Documentation
=============

The icons are used in ``mne/viz/_brain/_brain.py`` for the toolbar.
These Material design icons are provided by Google under the `Apache 2.0`_ license.


.. _Apache 2.0: https://github.com/google/material-design-icons/blob/master/LICENSE
