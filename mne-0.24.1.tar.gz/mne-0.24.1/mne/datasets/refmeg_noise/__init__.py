"""MEG reference-noise data set."""

from .refmeg_noise import data_path, has_refmeg_noise_data, get_version
