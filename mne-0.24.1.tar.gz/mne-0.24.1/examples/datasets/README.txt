
Examples on open datasets
-------------------------

Some demos on common/public datasets using MNE.
