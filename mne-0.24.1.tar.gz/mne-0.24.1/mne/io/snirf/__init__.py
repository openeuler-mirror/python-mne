"""SNIRF module for conversion to FIF."""

# Author: Robert Luke <mail@robertluke.net>
#
# License: BSD-3-Clause

from ._snirf import read_raw_snirf
