"""OPM dataset."""

from .opm import data_path, get_version
