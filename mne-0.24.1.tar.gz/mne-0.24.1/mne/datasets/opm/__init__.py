"""OPM dataset."""

from .opm import data_path, has_opm_data, get_version
