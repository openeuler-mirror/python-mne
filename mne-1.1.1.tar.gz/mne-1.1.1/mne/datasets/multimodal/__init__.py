"""Multimodal dataset."""

from .multimodal import data_path, get_version
