import os.path as op

data_dir = op.join(op.dirname(__file__), 'data')
