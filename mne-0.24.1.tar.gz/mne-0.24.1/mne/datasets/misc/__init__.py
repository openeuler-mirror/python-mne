"""MNE misc dataset."""

from ._misc import data_path
