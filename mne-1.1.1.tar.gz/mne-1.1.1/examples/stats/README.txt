
Statistics Examples
-------------------

Some examples of how to compute statistics on M/EEG data with MNE.

